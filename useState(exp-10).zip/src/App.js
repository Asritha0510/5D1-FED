import "./styles.css";
import ViewItems from './components/ViewItems';
export default function App() {
  return (
    <div className="App">
        <ViewItems />
    </div>
  );
}
