import "./styles.css";
import DigitalClock from './components/DigitalClock'
export default function App() {
  return (
    <div className="App">
      <h1>DigitalClock</h1>
        <DigitalClock />
    </div>
  );
}
