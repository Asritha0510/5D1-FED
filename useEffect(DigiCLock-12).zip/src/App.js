import "./styles.css";
import DigiClock from './components/DigiClock';
export default function App() {
  return (
    <div className="App">
        <DigiClock />
    </div>
  );
}
